#ifndef TNC_h
#define TNC_h

#include "Arduino.h"
#include <string.h>
#include <SoftwareSerial.h>

// defines for setting and clearing register bits
#ifndef cbi
#define cbi(sfr, bit) (_SFR_BYTE(sfr) &= ~_BV(bit))
#endif
#ifndef sbi
#define sbi(sfr, bit) (_SFR_BYTE(sfr) |= _BV(bit))
#endif


// 16MHz / 666 = 24.024kHz.  24kHz / 20 / 1201Hz baud
#define TIMER1_SEED 666
#define TX_DELAY_LEN 50

#define MAX_SZXMIT_SIZE 250

class TNC {
  public:
    TNC(void);
    void initInternal(int pinPTT);
    void initKISS(int pinTx, int pinRx);
    void xmitStart(char *szDest, char destSSID, char *szCall, char callSSID, char *szPath1, char path1SSID, char *szPath2, char path2SSID, bool usePath);
    void xmitEnd();
    void xmitString(char *sz);
    void xmitChar(char c);
    void xmitFloat(float f);
    void xmitLong(long lNumToSend, boolean bLeadingZero);
    boolean getNextBit(void);
    boolean noBitStuffing(void);
    int xmitLen(void);
    void xmitFlush(void);
  private:
    void _calcCRC(byte iBit);
    boolean _getNextBit(void);
    void _configTimers(void);
    void _startTimer1ISR(void);
    void _stopTimer1ISR(void);
  
    // member variables
    bool _modulateInternally;
    char _szXmit[MAX_SZXMIT_SIZE];    //array to hold the data to be transmitted
    int _iSZLen;    //Tracks the current size of the szXmit buffer  
    int _pinTx;
    int _pinRx;
    int _pinPTT;


byte _iSZPos = 0;    //Tracks the current byte being modulated out of the modem
int _iTxDelayRemaining = 0;
boolean _bNoStuffing = false;
unsigned int _CRC;
byte _iTxState = 0;

  
};


#endif

